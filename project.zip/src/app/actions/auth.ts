'use server';

import { cookies } from 'next/headers';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc, updateDoc } from 'firebase/firestore';
import { firebaseConfig } from '@/firebase/config';

/**
 * Helper to get the current target password from Firestore.
 */
async function getTargetPassword() {
  const app = !getApps().length ? initializeApp(firebaseConfig, 'auth-checker') : getApp('auth-checker');
  const db = getFirestore(app);
  
  let targetPassword = "na9ch"; 

  try {
    const securityDoc = await getDoc(doc(db, "adminConfig", "security"));
    if (securityDoc.exists()) {
      targetPassword = securityDoc.data().adminPassword || targetPassword;
    }
  } catch (e) {
    console.log("Using default fallback password");
  }
  return targetPassword;
}

/**
 * Server Action for secure admin authentication.
 */
export async function verifyAdminPortal(password: string) {
  try {
    const targetPassword = await getTargetPassword();

    if (password === targetPassword) {
      const cookieStore = await cookies();
      
      cookieStore.set('oran_admin_session', 'authenticated', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 60 * 60 * 24, // 24-hour session
        path: '/',
      });

      return { success: true };
    }

    return { success: false, error: "Invalid access code. Please check your credentials." };
  } catch (error) {
    return { success: false, error: "Authentication service currently unavailable." };
  }
}

/**
 * Server Action to securely update the portal access code.
 * Requires verification of the old password.
 */
export async function updatePortalCode(currentPassword: string, newPassword: string) {
  try {
    const targetPassword = await getTargetPassword();

    if (currentPassword !== targetPassword) {
      return { success: false, error: "Current access code is incorrect." };
    }

    const app = getApp('auth-checker');
    const db = getFirestore(app);
    const securityRef = doc(db, "adminConfig", "security");
    
    await updateDoc(securityRef, { adminPassword: newPassword });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: "Failed to update access code. Please try again." };
  }
}

/**
 * Server Action to securely clear the session.
 */
export async function logoutAdmin() {
  const cookieStore = await cookies();
  cookieStore.delete('oran_admin_session');
}

/**
 * Checks if the session cookie is present.
 */
export async function checkAdminSession() {
  const cookieStore = await cookies();
  return cookieStore.has('oran_admin_session');
}
