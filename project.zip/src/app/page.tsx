
import { Navbar } from "@/components/layout/Navbar";
import { Hero } from "@/components/sections/Hero";
import { Gallery } from "@/components/sections/Gallery";
import { Shop } from "@/components/sections/Shop";
import { Events } from "@/components/sections/Events";
import { JoinUs } from "@/components/sections/JoinUs";
import { Footer } from "@/components/layout/Footer";
import { Toaster } from "@/components/ui/toaster";

export default function Home() {
  return (
    <div className="min-h-screen bg-art-gradient">
      <Navbar />
      <main>
        <Hero />
        <Gallery />
        <Shop />
        <Events />
        <JoinUs />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
}
