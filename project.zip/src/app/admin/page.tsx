"use client";

import { useState, useEffect, useMemo, useTransition } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { 
  ImageIcon, 
  Calendar, 
  Users, 
  LogOut, 
  Trash2, 
  Settings, 
  ShieldCheck, 
  RefreshCcw,
  Upload,
  ShoppingBag,
  Bell,
  CheckCircle2,
  Clock,
  BarChart3,
  TrendingUp,
  DollarSign,
  Briefcase,
  Lock,
  Sparkles,
  Type,
  Link as LinkIcon,
  Globe,
  Instagram,
  Facebook,
  MessageSquare,
  Youtube,
  KeyRound,
  Languages
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  useFirestore, 
  useCollection, 
  useDoc, 
  useMemoFirebase, 
  setDocumentNonBlocking, 
  addDocumentNonBlocking, 
  deleteDocumentNonBlocking, 
  updateDocumentNonBlocking,
  useAuth, 
  useUser 
} from "@/firebase";
import { collection, doc, query, orderBy } from "firebase/firestore";
import { signInAnonymously } from "firebase/auth";
import { useToast } from "@/hooks/use-toast";
import { LArtelierLogo } from "@/components/ui/logo";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { verifyAdminPortal, logoutAdmin, checkAdminSession, updatePortalCode } from "@/app/actions/auth";
import { generateArtworkDescription } from "@/ai/flows/generate-artwork-description";

export default function AdminPage() {
  const router = useRouter();
  const { toast } = useToast();
  const firestore = useFirestore();
  const auth = useAuth();
  const { user } = useUser();
  const [isPending, startTransition] = useTransition();
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [isCheckingSession, setIsCheckingSession] = useState(true);

  // Memoize refs
  const artworksRef = useMemoFirebase(() => (isAuthenticated ? collection(firestore, "artworks") : null), [firestore, isAuthenticated]);
  const eventsRef = useMemoFirebase(() => (isAuthenticated ? collection(firestore, "events") : null), [firestore, isAuthenticated]);
  const membersRef = useMemoFirebase(() => (isAuthenticated ? collection(firestore, "members") : null), [firestore, isAuthenticated]);
  const productsRef = useMemoFirebase(() => (isAuthenticated ? collection(firestore, "products") : null), [firestore, isAuthenticated]);
  const ordersRef = useMemoFirebase(() => (isAuthenticated ? query(collection(firestore, "orders"), orderBy("createdAt", "desc")) : null), [firestore, isAuthenticated]);
  const settingsDocRef = useMemoFirebase(() => (isAuthenticated ? doc(firestore, "clubSettings", "global") : null), [firestore, isAuthenticated]);

  const { data: artworks } = useCollection(artworksRef);
  const { data: events } = useCollection(eventsRef);
  const { data: members } = useCollection(membersRef);
  const { data: products } = useCollection(productsRef);
  const { data: orders } = useCollection(ordersRef);
  const { data: settings } = useDoc(settingsDocRef);

  const [newArt, setNewArt] = useState({ title: "", artistFullName: "", medium: "Oil on Canvas", description: "", artistProfileLink: "", imageUrl: "", isFeatured: false });
  const [newEvent, setNewEvent] = useState({ title: "", description: "", date: "", time: "", location: "", coverImageUrl: "" });
  const [newProduct, setNewProduct] = useState({ name: "", description: "", price: 0, imageUrl: "" });

  const [clubSettingsForm, setClubSettingsForm] = useState({
    heroTitle: "",
    heroTitleAr: "",
    heroDescription: "",
    heroDescriptionAr: "",
    heroImageUrl: "",
    logoUrl: "",
    instagramLink: "",
    facebookLink: "",
    discordLink: "",
    youtubeLink: "",
    tagline: "",
    taglineAr: "",
    newAdminPassword: "",
    currentAdminPassword: ""
  });

  const pendingOrdersCount = orders?.filter(o => o.status === 'pending').length || 0;

  useEffect(() => {
    async function initSession() {
      const hasSession = await checkAdminSession();
      if (hasSession) {
        if (!user) {
          await signInAnonymously(auth);
        }
        setIsAuthenticated(true);
      }
      setIsCheckingSession(false);
    }
    initSession();
  }, [auth, user]);

  useEffect(() => {
    if (settings) {
      setClubSettingsForm(prev => ({
        ...prev,
        heroTitle: settings.heroTitle || "L'Artelier Oran",
        heroTitleAr: settings.heroTitleAr || "",
        heroDescription: settings.heroDescription || "A professional creative collaboration at USTO-MB.",
        heroDescriptionAr: settings.heroDescriptionAr || "",
        heroImageUrl: settings.heroImageUrl || "",
        logoUrl: settings.logoUrl || "",
        instagramLink: settings.instagramLink || "",
        facebookLink: settings.facebookLink || "",
        discordLink: settings.discordLink || "",
        youtubeLink: settings.youtubeLink || "",
        tagline: settings.tagline || "Redefining creative standards",
        taglineAr: settings.taglineAr || "",
      }));
    }
  }, [settings]);

  const stats = useMemo(() => {
    const totalRevenue = orders?.filter(o => o.status === 'completed').reduce((acc, order) => {
      const product = products?.find(p => p.id === order.productId);
      return acc + (product?.price || 0);
    }, 0) || 0;

    return { 
      totalRevenue, 
      orderData: [
        { name: 'Pending', count: orders?.filter(o => o.status === 'pending').length || 0 },
        { name: 'Completed', count: orders?.filter(o => o.status === 'completed').length || 0 }
      ],
      distributionData: [
        { name: 'Artworks', value: artworks?.length || 0 },
        { name: 'Events', value: events?.length || 0 },
        { name: 'Products', value: products?.length || 0 }
      ]
    };
  }, [orders, products, artworks, events]);

  const COLORS = ['#1976D2', '#D4AF37', '#E34234'];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const result = await verifyAdminPortal(passwordInput);
      if (result.success) {
        await signInAnonymously(auth);
        setIsAuthenticated(true);
        toast({ title: "Portal Secured", description: "Identity verified. Session active." });
      } else {
        toast({ variant: "destructive", title: "Access Denied", description: result.error });
      }
    });
  };

  const handleLogout = async () => {
    await logoutAdmin();
    await auth.signOut();
    setIsAuthenticated(false);
    router.push("/");
  };

  const handleAiDescribe = async () => {
    if (!newArt.title || !newArt.artistFullName) {
      toast({ variant: "destructive", title: "Missing info", description: "Enter title and artist name first." });
      return;
    }
    setIsGenerating(true);
    try {
      const desc = await generateArtworkDescription({
        title: newArt.title,
        artistName: newArt.artistFullName,
        medium: newArt.medium
      });
      setNewArt({ ...newArt, description: desc });
      toast({ title: "Description Generated", description: "AI has crafted a new story for this piece." });
    } catch (error) {
      toast({ variant: "destructive", title: "AI Generation Failed" });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileConvert = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64: string) => void) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast({ variant: "destructive", title: "File too large", description: "Maximum size 2MB." });
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => callback(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsDocRef) return;
    setIsSaving(true);
    
    try {
      const { newAdminPassword, currentAdminPassword, ...publicSettings } = clubSettingsForm;
      
      setDocumentNonBlocking(settingsDocRef, { 
        ...publicSettings, 
        updatedAt: new Date().toISOString() 
      }, { merge: true });

      if (newAdminPassword) {
        if (!currentAdminPassword) {
          toast({ variant: "destructive", title: "Verification Required", description: "Please enter your current access code to set a new one." });
          setIsSaving(false);
          return;
        }

        const result = await updatePortalCode(currentAdminPassword, newAdminPassword);
        if (result.success) {
          toast({ title: "Security Updated", description: "Your portal access code has been changed." });
          setClubSettingsForm(prev => ({ ...prev, newAdminPassword: "", currentAdminPassword: "" }));
        } else {
          toast({ variant: "destructive", title: "Security Error", description: result.error });
          setIsSaving(false);
          return;
        }
      }

      toast({ title: "Settings Saved", description: "Global changes applied successfully." });
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "Could not save settings." });
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddArt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!artworksRef || !newArt.title || !newArt.imageUrl) return;
    const timestamp = new Date().toISOString();
    addDocumentNonBlocking(artworksRef, { ...newArt, createdAt: timestamp, updatedAt: timestamp });
    toast({ title: "Art Published" });
    setNewArt({ title: "", artistFullName: "", medium: "Oil on Canvas", description: "", artistProfileLink: "", imageUrl: "", isFeatured: false });
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productsRef || !newProduct.name) return;
    const timestamp = new Date().toISOString();
    addDocumentNonBlocking(productsRef, { ...newProduct, createdAt: timestamp, updatedAt: timestamp });
    toast({ title: "Product Added" });
    setNewProduct({ name: "", description: "", price: 0, imageUrl: "" });
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventsRef || !newEvent.title) return;
    const timestamp = new Date().toISOString();
    addDocumentNonBlocking(eventsRef, { ...newEvent, createdAt: timestamp, updatedAt: timestamp });
    toast({ title: "Event Added" });
    setNewEvent({ title: "", description: "", date: "", time: "", location: "", coverImageUrl: "" });
  };

  if (isCheckingSession) {
    return (
      <div className="min-h-screen bg-art-gradient flex items-center justify-center">
        <RefreshCcw className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-art-gradient flex items-center justify-center p-6">
        <Card className="w-full max-w-md border-none shadow-2xl overflow-hidden rounded-[3rem] bg-card/95 backdrop-blur-xl">
          <div className="bg-gradient-to-r from-primary via-[#D4AF37] to-secondary h-2 w-full" />
          <CardHeader className="text-center space-y-6 pt-16">
            <div className="w-28 h-28 mx-auto p-2 bg-foreground/5 rounded-full flex items-center justify-center">
              <Lock className="w-12 h-12 text-primary" />
            </div>
            <div className="space-y-2">
              <CardTitle className="font-headline text-5xl font-black text-gradient">Secure Portal</CardTitle>
              <CardDescription className="text-sm font-black uppercase tracking-[0.3em] opacity-60">Admin Authentication Required</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="pb-16 px-12">
            <form onSubmit={handleLogin} className="space-y-8">
              <div className="space-y-3">
                <Label htmlFor="pass" className="text-muted-foreground font-black ml-1 uppercase text-[10px] tracking-[0.3em]">SECURE ACCESS CODE</Label>
                <Input 
                  id="pass" 
                  type="password" 
                  value={passwordInput} 
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••" 
                  className="rounded-2xl h-16 bg-muted/30 border-transparent focus:border-primary text-center text-4xl tracking-[0.5em] font-black"
                />
              </div>
              <Button type="submit" className="w-full bg-foreground h-16 rounded-2xl text-xl font-black shadow-2xl transition-all hover:scale-[1.02] active:scale-95" disabled={isPending}>
                {isPending ? <RefreshCcw className="w-6 h-6 animate-spin" /> : "Access Portal"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card/90 backdrop-blur-2xl border-b border-border/50 px-12 py-8 flex items-center justify-between sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 shadow-2xl shadow-primary/20 rounded-2xl">
            <LArtelierLogo />
          </div>
          <div>
            <h1 className="font-headline text-3xl font-black tracking-tighter leading-none">Collaboration <span className="text-gold-gradient">Management</span></h1>
            <p className="text-[10px] text-muted-foreground font-black uppercase tracking-[0.3em] mt-2 flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" /> L'Artelier Oran x LMHTY
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={handleLogout} className="text-muted-foreground hover:text-destructive hover:bg-destructive/5 rounded-2xl font-black px-8 h-12">
            <LogOut className="w-5 h-5 mr-3" /> Terminate Session
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-12 space-y-12">
        <Tabs defaultValue="analytics" className="space-y-12">
          <TabsList className="bg-muted/30 border border-border/50 p-2 rounded-[2.5rem] h-auto flex-wrap gap-2 shadow-inner">
            <TabsTrigger value="analytics" className="rounded-2xl py-4 px-10 data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <BarChart3 className="w-5 h-5 mr-3" /> Analytics
            </TabsTrigger>
            <TabsTrigger value="gallery" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <ImageIcon className="w-5 h-5 mr-3" /> Gallery
            </TabsTrigger>
            <TabsTrigger value="shop" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <ShoppingBag className="w-5 h-5 mr-3" /> Shop
            </TabsTrigger>
            <TabsTrigger value="orders" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all relative">
              <Bell className="w-5 h-5 mr-3" /> Orders
              {pendingOrdersCount > 0 && <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full border-2 border-background flex items-center justify-center text-[10px] text-white">{pendingOrdersCount}</span>}
            </TabsTrigger>
            <TabsTrigger value="events" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <Calendar className="w-5 h-5 mr-3" /> Schedule
            </TabsTrigger>
            <TabsTrigger value="members" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <Users className="w-5 h-5 mr-3" /> Community
            </TabsTrigger>
            <TabsTrigger value="settings" className="rounded-2xl py-4 px-10 data-[state=active]:bg-primary data-[state=active]:text-white data-[state=active]:shadow-2xl font-black uppercase tracking-widest text-xs transition-all">
              <Settings className="w-5 h-5 mr-3" /> Global Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-12 animate-in fade-in duration-700">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-none shadow-xl rounded-[2rem] bg-card overflow-hidden group hover:scale-[1.02] transition-transform duration-500">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-green-500/10 flex items-center justify-center text-green-600">
                    <DollarSign className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Revenue</p>
                    <h3 className="text-3xl font-black">{stats.totalRevenue} DZD</h3>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-xl rounded-[2rem] bg-card overflow-hidden group hover:scale-[1.02] transition-transform duration-500">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                    <Users className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Community</p>
                    <h3 className="text-3xl font-black">{members?.length || 0}</h3>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-xl rounded-[2rem] bg-card overflow-hidden group hover:scale-[1.02] transition-transform duration-500">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-secondary/10 flex items-center justify-center text-secondary">
                    <ImageIcon className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Artworks</p>
                    <h3 className="text-3xl font-black">{artworks?.length || 0}</h3>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-xl rounded-[2rem] bg-card overflow-hidden group hover:scale-[1.02] transition-transform duration-500">
                <CardContent className="p-8 flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
                    <Calendar className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Events</p>
                    <h3 className="text-3xl font-black">{events?.length || 0}</h3>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
                <CardHeader className="p-10 bg-muted/5 border-b border-border/50">
                  <div className="flex items-center gap-4">
                    <TrendingUp className="text-primary w-8 h-8" />
                    <div>
                      <CardTitle className="text-2xl font-black uppercase tracking-tight">Order Activity</CardTitle>
                      <CardDescription className="font-bold">Pending vs Completed Transactions</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-10 h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.orderData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} className="font-black text-[10px] uppercase tracking-widest" />
                      <YAxis axisLine={false} tickLine={false} className="font-bold" />
                      <Tooltip 
                        contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.1)' }}
                        itemStyle={{ fontWeight: '900', color: '#1976D2' }}
                      />
                      <Bar dataKey="count" fill="#1976D2" radius={[12, 12, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
                <CardHeader className="p-10 bg-muted/5 border-b border-border/50">
                  <div className="flex items-center gap-4">
                    <Briefcase className="text-secondary w-8 h-8" />
                    <div>
                      <CardTitle className="text-2xl font-black uppercase tracking-tight">Ecosystem Mix</CardTitle>
                      <CardDescription className="font-bold">Distribution of Collaborative Content</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-10 h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stats.distributionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={120}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {stats.distributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ borderRadius: '1.5rem', border: 'none' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="gallery" className="grid lg:grid-cols-3 gap-12">
            <Card className="lg:col-span-1 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10">
                <CardTitle className="text-2xl font-black uppercase tracking-tight">Curate Art</CardTitle>
              </CardHeader>
              <CardContent className="pt-12 space-y-6">
                <form onSubmit={handleAddArt} className="space-y-6">
                  {newArt.imageUrl && (
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden border">
                      <Image src={newArt.imageUrl} alt="Preview" fill className="object-cover" unoptimized />
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] tracking-[0.2em] uppercase opacity-60">TITLE</Label>
                    <Input value={newArt.title} onChange={e => setNewArt({...newArt, title: e.currentTarget.value})} placeholder="Artwork Name" className="rounded-2xl h-14 bg-muted/20 border-transparent focus:border-primary" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] tracking-[0.2em] uppercase opacity-60">ARTIST</Label>
                    <Input value={newArt.artistFullName} onChange={e => setNewArt({...newArt, artistFullName: e.currentTarget.value})} placeholder="Full Name" className="rounded-2xl h-14 bg-muted/20 border-transparent focus:border-primary" />
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] tracking-[0.2em] uppercase opacity-60">DESCRIPTION</Label>
                    <div className="relative">
                      <Textarea value={newArt.description} onChange={e => setNewArt({...newArt, description: e.currentTarget.value})} placeholder="Tell the story..." className="rounded-2xl min-h-[120px] bg-muted/20 border-transparent focus:border-primary pr-12" />
                      <Button 
                        type="button" 
                        size="icon" 
                        variant="ghost" 
                        onClick={handleAiDescribe}
                        disabled={isGenerating}
                        className="absolute bottom-3 right-3 text-primary hover:bg-primary/10 rounded-xl"
                      >
                        {isGenerating ? <RefreshCcw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="font-black text-[10px] tracking-[0.2em] uppercase opacity-60">PICTURE SOURCE</Label>
                    <div className="relative">
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="absolute inset-0 opacity-0 cursor-pointer" 
                        onChange={(e) => handleFileConvert(e, (base64) => setNewArt({...newArt, imageUrl: base64}))}
                      />
                      <Button type="button" variant="outline" className="w-full rounded-2xl h-14 border-dashed border-2">
                        <Upload className="w-5 h-5 mr-2" /> Select Image
                      </Button>
                    </div>
                  </div>
                  <Button type="submit" className="w-full bg-primary h-16 rounded-2xl text-lg font-black shadow-xl" disabled={!newArt.title || !newArt.imageUrl}>Publish Masterpiece</Button>
                </form>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10">
                <CardTitle className="text-2xl font-black uppercase tracking-tight">Collection</CardTitle>
              </CardHeader>
              <CardContent className="pt-8">
                <Table>
                  <TableBody>
                    {artworks?.map((art) => (
                      <TableRow key={art.id} className="border-b border-border/50">
                        <TableCell className="font-bold py-8">{art.title}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" className="text-destructive rounded-xl" onClick={() => deleteDocumentNonBlocking(doc(firestore, "artworks", art.id))}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="shop" className="grid lg:grid-cols-3 gap-12">
            <Card className="lg:col-span-1 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">Add Product</CardTitle></CardHeader>
              <CardContent className="pt-12 space-y-6">
                <form onSubmit={handleAddProduct} className="space-y-6">
                  {newProduct.imageUrl && (
                    <div className="relative aspect-square w-full rounded-2xl overflow-hidden border">
                      <Image src={newProduct.imageUrl} alt="Preview" fill className="object-cover" unoptimized />
                    </div>
                  )}
                  <Input value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} placeholder="Product Name" className="rounded-2xl h-14 bg-muted/20 border-transparent" />
                  <Input type="number" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: parseFloat(e.target.value)})} placeholder="Price" className="rounded-2xl h-14 bg-muted/20 border-transparent" />
                  <div className="relative">
                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleFileConvert(e, (base64) => setNewProduct({...newProduct, imageUrl: base64}))} />
                    <Button type="button" variant="outline" className="w-full rounded-2xl h-14 border-dashed border-2">Select Image</Button>
                  </div>
                  <Button type="submit" className="w-full bg-primary h-16 rounded-2xl text-lg font-black shadow-xl">Add to Shop</Button>
                </form>
              </CardContent>
            </Card>
            <Card className="lg:col-span-2 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">Active Shop</CardTitle></CardHeader>
              <CardContent className="pt-8">
                <Table>
                  <TableBody>
                    {products?.map((prod) => (
                      <TableRow key={prod.id} className="border-b border-border/50">
                        <TableCell className="font-bold py-8">{prod.name}</TableCell>
                        <TableCell className="font-black text-primary">{prod.price} DZD</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" className="text-destructive rounded-xl" onClick={() => deleteDocumentNonBlocking(doc(firestore, "products", prod.id))}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">Orders</CardTitle></CardHeader>
              <CardContent className="pt-8">
                <Table>
                  <TableBody>
                    {orders?.map((order) => (
                      <TableRow key={order.id} className="border-b border-border/50">
                        <TableCell className="py-8">
                          <div className="font-bold">{order.customerName}</div>
                          <div className="text-[10px] text-muted-foreground font-black">{order.customerPhone}</div>
                        </TableCell>
                        <TableCell className="font-black text-xs text-primary">{order.productName}</TableCell>
                        <TableCell>
                          <Badge variant={order.status === 'completed' ? 'default' : 'secondary'} className="rounded-full px-4 font-black">
                            {order.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          {order.status === 'pending' && (
                            <Button variant="outline" size="sm" className="rounded-xl font-black text-[10px]" onClick={() => updateDocumentNonBlocking(doc(firestore, "orders", order.id), { status: 'completed' })}>
                              COMPLETE
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="events" className="grid lg:grid-cols-3 gap-12">
            <Card className="lg:col-span-1 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">New Event</CardTitle></CardHeader>
              <CardContent className="pt-12 space-y-6">
                <form onSubmit={handleAddEvent} className="space-y-6">
                  <Input value={newEvent.title} onChange={e => setNewEvent({...newEvent, title: e.target.value})} placeholder="Event Title" className="rounded-2xl h-14 bg-muted/20 border-transparent" />
                  <Input type="date" value={newEvent.date} onChange={e => setNewEvent({...newEvent, date: e.target.value})} className="rounded-2xl h-14 bg-muted/20 border-transparent" />
                  <Input value={newEvent.location} onChange={e => setNewEvent({...newEvent, location: e.target.value})} placeholder="Location" className="rounded-2xl h-14 bg-muted/20 border-transparent" />
                  <div className="relative">
                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleFileConvert(e, (base64) => setNewEvent({...newEvent, coverImageUrl: base64}))} />
                    <Button type="button" variant="outline" className="w-full rounded-2xl h-14 border-dashed border-2">Cover Image</Button>
                  </div>
                  <Button type="submit" className="w-full bg-primary h-16 rounded-2xl text-lg font-black shadow-xl">Schedule Event</Button>
                </form>
              </CardContent>
            </Card>
            <Card className="lg:col-span-2 border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">Schedule</CardTitle></CardHeader>
              <CardContent className="pt-8">
                <Table>
                  <TableBody>
                    {events?.map((ev) => (
                      <TableRow key={ev.id} className="border-b border-border/50">
                        <TableCell className="font-bold py-8">{ev.title}</TableCell>
                        <TableCell className="text-muted-foreground">{ev.date}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" className="text-destructive rounded-xl" onClick={() => deleteDocumentNonBlocking(doc(firestore, "events", ev.id))}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="members">
            <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
              <CardHeader className="bg-muted/5 pb-10"><CardTitle className="text-2xl font-black">Active Community</CardTitle></CardHeader>
              <CardContent className="pt-8">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="font-black text-[10px] uppercase">Member</TableHead>
                      <TableHead className="font-black text-[10px] uppercase">Department</TableHead>
                      <TableHead className="font-black text-[10px] uppercase">Contact</TableHead>
                      <TableHead className="text-right font-black text-[10px] uppercase">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {members?.map((mem) => (
                      <TableRow key={mem.id} className="border-b border-border/50">
                        <TableCell className="py-8 font-bold">{mem.fullName}</TableCell>
                        <TableCell>{mem.universityDepartment}</TableCell>
                        <TableCell className="text-muted-foreground">{mem.email}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" className="text-destructive rounded-xl" onClick={() => deleteDocumentNonBlocking(doc(firestore, "members", mem.id))}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-12 animate-in fade-in duration-700">
            <form onSubmit={handleSaveSettings} className="space-y-12">
              <div className="grid lg:grid-cols-2 gap-12">
                {/* Visual Branding */}
                <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
                  <CardHeader className="bg-muted/5 pb-10">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                        <Globe className="w-6 h-6" />
                      </div>
                      <CardTitle className="text-2xl font-black uppercase tracking-tight">Main Interface</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-10 space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2">
                           <Type className="w-3 h-3" /> Hero Title (EN/FR)
                        </Label>
                        <Input 
                          value={clubSettingsForm.heroTitle} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, heroTitle: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-primary font-bold"
                        />
                      </div>
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2 text-primary">
                           <Languages className="w-3 h-3" /> Hero Title (AR)
                        </Label>
                        <Input 
                          dir="rtl"
                          value={clubSettingsForm.heroTitleAr} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, heroTitleAr: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-primary font-arabic font-bold"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2">
                          <Type className="w-3 h-3" /> Hero Description (EN/FR)
                        </Label>
                        <Textarea 
                          value={clubSettingsForm.heroDescription} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, heroDescription: e.target.value})} 
                          className="min-h-[120px] rounded-2xl bg-muted/20 border-transparent focus:border-primary"
                        />
                      </div>
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2 text-primary">
                          <Languages className="w-3 h-3" /> Hero Description (AR)
                        </Label>
                        <Textarea 
                          dir="rtl"
                          value={clubSettingsForm.heroDescriptionAr} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, heroDescriptionAr: e.target.value})} 
                          className="min-h-[120px] rounded-2xl bg-muted/20 border-transparent focus:border-primary font-arabic"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2">
                           Tagline (EN/FR)
                        </Label>
                        <Input 
                          value={clubSettingsForm.tagline} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, tagline: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent"
                        />
                      </div>
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60 flex items-center gap-2 text-primary">
                           Tagline (AR)
                        </Label>
                        <Input 
                          dir="rtl"
                          value={clubSettingsForm.taglineAr} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, taglineAr: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent font-arabic"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-6">
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60">Hero Image</Label>
                        <div className="relative">
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="absolute inset-0 opacity-0 cursor-pointer" 
                            onChange={(e) => handleFileConvert(e, (base64) => setClubSettingsForm({...clubSettingsForm, heroImageUrl: base64}))}
                          />
                          <Button type="button" variant="outline" className="w-full h-14 rounded-2xl border-dashed">Update Cover</Button>
                        </div>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60">Brand Logo</Label>
                      <div className="flex items-center gap-6 p-4 bg-muted/10 rounded-[2rem]">
                        <div className="w-20 h-20 bg-card rounded-2xl shadow-xl p-2">
                           <LArtelierLogo forceSvg={false} />
                        </div>
                        <div className="flex-1 relative">
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="absolute inset-0 opacity-0 cursor-pointer" 
                            onChange={(e) => handleFileConvert(e, (base64) => setClubSettingsForm({...clubSettingsForm, logoUrl: base64}))}
                          />
                          <Button type="button" variant="outline" className="w-full h-14 rounded-2xl border-dashed">Replace Logo</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-12">
                  {/* Social Media */}
                  <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
                    <CardHeader className="bg-muted/5 pb-10">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-secondary/10 rounded-2xl flex items-center justify-center text-secondary">
                          <LinkIcon className="w-6 h-6" />
                        </div>
                        <CardTitle className="text-2xl font-black uppercase tracking-tight">Social Media</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-10 space-y-6">
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 rounded-2xl bg-pink-500/10 flex items-center justify-center text-pink-600">
                          <Instagram className="w-6 h-6" />
                        </div>
                        <Input 
                          placeholder="Instagram URL" 
                          value={clubSettingsForm.instagramLink} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, instagramLink: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent"
                        />
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 rounded-2xl bg-blue-600/10 flex items-center justify-center text-blue-600">
                          <Facebook className="w-6 h-6" />
                        </div>
                        <Input 
                          placeholder="Facebook URL" 
                          value={clubSettingsForm.facebookLink} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, facebookLink: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent"
                        />
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-500">
                          <MessageSquare className="w-6 h-6" />
                        </div>
                        <Input 
                          placeholder="Discord URL" 
                          value={clubSettingsForm.discordLink} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, discordLink: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent"
                        />
                      </div>
                      <div className="flex items-center gap-6">
                        <div className="w-12 h-12 rounded-2xl bg-red-600/10 flex items-center justify-center text-red-600">
                          <Youtube className="w-6 h-6" />
                        </div>
                        <Input 
                          placeholder="YouTube URL" 
                          value={clubSettingsForm.youtubeLink} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, youtubeLink: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Security */}
                  <Card className="border-none shadow-2xl rounded-[3rem] overflow-hidden bg-card">
                    <CardHeader className="bg-muted/5 pb-10">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#D4AF37]/10 rounded-2xl flex items-center justify-center text-[#D4AF37]">
                          <Lock className="w-6 h-6" />
                        </div>
                        <CardTitle className="text-2xl font-black uppercase tracking-tight">Access Control</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-10 space-y-6">
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60">Current Access Code</Label>
                        <Input 
                          type="password"
                          placeholder="Verify current code..." 
                          value={clubSettingsForm.currentAdminPassword} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, currentAdminPassword: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-[#D4AF37] text-center text-xl tracking-[0.2em]"
                        />
                      </div>
                      <div className="space-y-4">
                        <Label className="font-black text-[10px] tracking-[0.3em] uppercase opacity-60">New Access Code</Label>
                        <Input 
                          type="password"
                          placeholder="Enter new code..." 
                          value={clubSettingsForm.newAdminPassword} 
                          onChange={e => setClubSettingsForm({...clubSettingsForm, newAdminPassword: e.target.value})} 
                          className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-[#D4AF37] text-center text-xl tracking-[0.2em]"
                        />
                        <p className="text-[10px] text-muted-foreground font-medium px-2 italic">
                          Provide both current and new codes to update your security settings.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="flex justify-end pt-12">
                <Button type="submit" className="bg-foreground text-background h-16 rounded-2xl px-16 font-black text-lg shadow-2xl hover:scale-105 transition-all" disabled={isSaving}>
                  {isSaving ? <RefreshCcw className="w-6 h-6 animate-spin" /> : "Apply Global Changes"}
                </Button>
              </div>
            </form>
          </TabsContent>
          
        </Tabs>
      </main>
    </div>
  );
}
