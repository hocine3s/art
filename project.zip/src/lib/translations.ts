export type Language = 'en' | 'fr' | 'ar';

export const translations = {
  en: {
    nav: {
      gallery: "Gallery",
      shop: "Shop",
      events: "Events",
      joinUs: "Join Us",
      collab: "Collab",
      adminAccess: "Admin Access (Double Click)"
    },
    hero: {
      badge: "Official Collaboration",
      description: "A professional creative collaboration at USTO-MB. Where traditional artistry meets premium modern vision.",
      explore: "Explore Gallery",
      join: "Join Us"
    },
    gallery: {
      title: "Student Masterpieces",
      subtitle: "Discover a diverse collection of creative works ranging from traditional oil paintings to modern digital illustrations.",
      loading: "Loading gallery...",
      viewProfile: "View Profile"
    },
    shop: {
      badge: "Exclusive Shop",
      title: "Collab Merchandise",
      subtitle: "Support our artists by owning a piece of the movement. Limited edition collaborative products.",
      buyNow: "Buy Now",
      opening: "Opening Shop...",
      confirmOrder: "Confirm Order",
      ordering: "Ordering",
      fullName: "Your Full Name",
      phone: "Phone Number",
      email: "Email (Optional)",
      confirm: "Confirm Order",
      orderReceived: "Order Received!",
      orderDescription: "We'll contact you shortly to confirm your art piece."
    },
    events: {
      title: "Upcoming Happenings",
      subtitle: "From workshops to exhibitions, there's always something artistic happening at L'Artelier.",
      loading: "Loading club events...",
      saveDate: "Save the date",
      dateTbd: "Date TBD",
      timeTbd: "Time TBD"
    },
    join: {
      title: "Join Our Community",
      subtitle: "Become part of USTO-MB's most creative family. All departments are welcome!",
      fullName: "Full Name",
      universityEmail: "University Email",
      phone: "Phone Number",
      department: "Department / Major",
      portfolio: "Portfolio Link (Optional)",
      submit: "Send Application",
      submitting: "Submitting...",
      success: "Welcome aboard! 🎨",
      successDesc: "Your registration has been successfully submitted.",
      error: "Registration failed",
      errorDesc: "Something went wrong. Please try again later."
    },
    footer: {
      tagline: "The premier student art collective at USTO-MB. Redefining creative standards through a professional lens.",
      navTitle: "Navigation",
      connTitle: "Global Connection",
      digitalExp: "Digital Experience by",
      location: "Professional Collaboration • Mohamed Boudiaf, Oran."
    }
  },
  fr: {
    nav: {
      gallery: "Galerie",
      shop: "Boutique",
      events: "Événements",
      joinUs: "S'inscrire",
      collab: "Collab",
      adminAccess: "Accès Admin (Double Clic)"
    },
    hero: {
      badge: "Collaboration Officielle",
      description: "Une collaboration créative professionnelle à l'USTO-MB. Où l'art traditionnel rencontre une vision moderne premium.",
      explore: "Explorer la Galerie",
      join: "Rejoignez-nous"
    },
    gallery: {
      title: "Chefs-d'œuvre Étudiants",
      subtitle: "Découvrez une collection diversifiée d'œuvres créatives allant des peintures à l'huile traditionnelles aux illustrations numériques modernes.",
      loading: "Chargement de la galerie...",
      viewProfile: "Voir le Profil"
    },
    shop: {
      badge: "Boutique Exclusive",
      title: "Produits Collab",
      subtitle: "Soutenez nos artistes en possédant une pièce du mouvement. Produits collaboratifs en édition limitée.",
      buyNow: "Acheter",
      opening: "Ouverture de la boutique...",
      confirmOrder: "Confirmer la Commande",
      ordering: "Commande de",
      fullName: "Votre Nom Complet",
      phone: "Numéro de Téléphone",
      email: "Email (Optionnel)",
      confirm: "Confirmer la Commande",
      orderReceived: "Commande Reçue !",
      orderDescription: "Nous vous contacterons bientôt pour confirmer votre pièce d'art."
    },
    events: {
      title: "Événements à Venir",
      subtitle: "Des ateliers aux expositions, il se passe toujours quelque chose d'artistique à L'Artelier.",
      loading: "Chargement des événements...",
      saveDate: "Réserver la date",
      dateTbd: "Date à déterminer",
      timeTbd: "Heure à déterminer"
    },
    join: {
      title: "Rejoignez la Communauté",
      subtitle: "Faites partie de la famille la plus créative de l'USTO-MB. Tous les départements sont les bienvenus !",
      fullName: "Nom Complet",
      universityEmail: "Email Universitaire",
      phone: "Numéro de Téléphone",
      department: "Département / Filière",
      portfolio: "Lien Portfolio (Optionnel)",
      submit: "Envoyer l'Inscription",
      submitting: "Envoi...",
      success: "Bienvenue à bord ! 🎨",
      successDesc: "Votre inscription a été soumise avec succès.",
      error: "Échec de l'inscription",
      errorDesc: "Une erreur est survenue. Veuillez réessayer plus tard."
    },
    footer: {
      tagline: "Le premier collectif d'art étudiant à l'USTO-MB. Redéfinir les standards créatifs à travers un prisme professionnel.",
      navTitle: "Navigation",
      connTitle: "Connexion Globale",
      digitalExp: "Expérience Numérique par",
      location: "Collaboration Professionnelle • Mohamed Boudiaf, Oran."
    }
  },
  ar: {
    nav: {
      gallery: "المعرض",
      shop: "المتجر",
      events: "الفعاليات",
      joinUs: "انضم إلينا",
      collab: "تعاون",
      adminAccess: "دخول المسؤول (نقرة مزدوجة)"
    },
    hero: {
      badge: "تعاون رسمي",
      description: "تعاون إبداعي احترافي في جامعة USTO-MB. حيث يلتقي الفن التقليدي بالرؤية الحديثة المتميزة.",
      explore: "استكشف المعرض",
      join: "انضم إلينا"
    },
    gallery: {
      title: "روائع الطلاب",
      subtitle: "اكتشف مجموعة متنوعة من الأعمال الإبداعية التي تتراوح من اللوحات الزيتية التقليدية إلى الرسوم الرقمية الحديثة.",
      loading: "جاري تحميل المعرض...",
      viewProfile: "عرض الملف الشخصي"
    },
    shop: {
      badge: "متجر حصري",
      title: "منتجات التعاون",
      subtitle: "ادعم فنانينا من خلال امتلاك قطعة من الحركة. منتجات تعاونية بإصدار محدود.",
      buyNow: "اشتري الآن",
      opening: "جاري فتح المتجر...",
      confirmOrder: "تأكيد الطلب",
      ordering: "طلب",
      fullName: "الاسم الكامل",
      phone: "رقم الهاتف",
      email: "البريد الإلكتروني (اختياري)",
      confirm: "تأكيد الطلب",
      orderReceived: "تم استلام الطلب!",
      orderDescription: "سنتصل بك قريبًا لتأكيد قطعة الفن الخاصة بك."
    },
    events: {
      title: "الفعاليات القادمة",
      subtitle: "من ورش العمل إلى المعارض، هناك دائمًا شيء فني يحدث في لارتوليي.",
      loading: "جاري تحميل الفعاليات...",
      saveDate: "احفظ التاريخ",
      dateTbd: "التاريخ يحدد لاحقاً",
      timeTbd: "الوقت يحدد لاحقاً"
    },
    join: {
      title: "انضم إلى مجتمعنا",
      subtitle: "كن جزءاً من أكثر العائلات إبداعاً في جامعة USTO-MB. نرحب بجميع التخصصات!",
      fullName: "الاسم الكامل",
      universityEmail: "البريد الإلكتروني الجامعي",
      phone: "رقم الهاتف",
      department: "القسم / التخصص",
      portfolio: "رابط الملف الشخصي (اختياري)",
      submit: "إرسال الطلب",
      submitting: "جاري الإرسال...",
      success: "أهلاً بك معنا! 🎨",
      successDesc: "تم إرسال تسجيلك بنجاح.",
      error: "فشل التسجيل",
      errorDesc: "حدث خطأ ما. يرجى المحاولة لاحقاً.",
    },
    footer: {
      tagline: "أول تجمع فني طلابي في جامعة USTO-MB. إعادة تعريف المعايير الإبداعية من منظور احترافي.",
      navTitle: "التنقل",
      connTitle: "اتصال عالمي",
      digitalExp: "تجربة رقمية بواسطة",
      location: "تعاون احترافي • محمد بوضياف، وهران."
    }
  }
};