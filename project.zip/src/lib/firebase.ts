/**
 * This file would normally initialize Firebase. 
 * For this scaffold, we provide a simulated interface that handles the local state 
 * or interactions expected by the UI.
 */

export interface Artwork {
  id: string;
  title: string;
  artistName: string;
  description: string;
  imageUrl: string;
  artistLink: string;
  medium: string;
}

export interface ClubEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  coverImage: string;
  description: string;
}

export interface Member {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  department: string;
  portfolioLink?: string;
  registeredAt: string;
}

export interface ClubSettings {
  instagram: string;
  facebook: string;
  discord: string;
  youtube: string;
  tagline: string;
}

// Global state for demonstration purposes (simulating Firestore)
let artworks: Artwork[] = [
  {
    id: '1',
    title: 'Ephemeral Dreams',
    artistName: 'Sarra Benmoussa',
    description: 'A study on the fleeting nature of subconscious thoughts during dawn.',
    imageUrl: 'https://picsum.photos/seed/art1/600/800',
    artistLink: 'https://instagram.com/sarra_arts',
    medium: 'Oil on Canvas'
  },
  {
    id: '2',
    title: 'Oran Vibrations',
    artistName: 'Mohamed Amine',
    description: 'Capturing the rhythmic energy of the coastal city through vibrant colors.',
    imageUrl: 'https://picsum.photos/seed/art2/800/600',
    artistLink: 'https://behance.net/amine_dz',
    medium: 'Digital Art'
  },
  {
    id: '3',
    title: 'Silent Guardian',
    artistName: 'Leila Touati',
    description: 'A minimalist sculpture representing the protection of cultural heritage.',
    imageUrl: 'https://picsum.photos/seed/art3/600/600',
    artistLink: 'https://instagram.com/leila_sculpts',
    medium: 'Clay Sculpture'
  }
];

let events: ClubEvent[] = [
  {
    id: 'e1',
    title: "Exposition d'Art Annuelle",
    date: '2024-05-15',
    time: '14:00',
    location: 'USTO-MB Main Hall',
    coverImage: 'https://picsum.photos/seed/event1/800/500',
    description: 'Our biggest event of the year showcasing over 100 student works.'
  },
  {
    id: 'e2',
    title: 'Painting Workshop: Mixed Media',
    date: '2024-06-02',
    time: '10:00',
    location: 'L\'Artelier Studio B-12',
    coverImage: 'https://picsum.photos/seed/event2/800/500',
    description: 'Learn to combine different mediums to create textured masterpieces.'
  }
];

let clubSettings: ClubSettings = {
  instagram: "https://www.instagram.com/artelieroran",
  facebook: "#",
  discord: "#",
  youtube: "#",
  tagline: "The best art club in town !!"
};

let members: Member[] = [];

// Simulated API Calls
export const db = {
  getArtworks: async () => [...artworks],
  addArtwork: async (art: Omit<Artwork, 'id'>) => {
    const newArt = { ...art, id: Math.random().toString(36).substr(2, 9) };
    artworks.push(newArt);
    return newArt;
  },
  deleteArtwork: async (id: string) => {
    artworks = artworks.filter(a => a.id !== id);
  },
  getEvents: async () => [...events],
  addEvent: async (ev: Omit<ClubEvent, 'id'>) => {
    const newEv = { ...ev, id: Math.random().toString(36).substr(2, 9) };
    events.push(newEv);
    return newEv;
  },
  deleteEvent: async (id: string) => {
    events = events.filter(e => e.id !== id);
  },
  registerMember: async (mem: Omit<Member, 'id' | 'registeredAt'>) => {
    const newMem = { 
      ...mem, 
      id: Math.random().toString(36).substr(2, 9),
      registeredAt: new Date().toISOString()
    };
    members.push(newMem);
    return newMem;
  },
  getMembers: async () => [...members],
  getSettings: async () => ({...clubSettings}),
  updateSettings: async (settings: ClubSettings) => {
    clubSettings = {...settings};
    return clubSettings;
  }
};

export const auth = {
  isAdmin: () => {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('oran_canvas_admin') === 'true';
  },
  login: async (password: string) => {
    // Password set to "na9ch" as requested
    if (password === 'na9ch') {
      localStorage.setItem('oran_canvas_admin', 'true');
      return true;
    }
    return false;
  },
  logout: () => {
    localStorage.removeItem('oran_canvas_admin');
  }
};