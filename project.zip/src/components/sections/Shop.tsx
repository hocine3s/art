"use client";

import { useState } from "react";
import Image from "next/image";
import { ShoppingCart, Package, RefreshCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useFirestore, useCollection, useMemoFirebase, addDocumentNonBlocking } from "@/firebase";
import { collection } from "firebase/firestore";
import { useLanguage } from "@/components/language-provider";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export function Shop() {
  const { toast } = useToast();
  const firestore = useFirestore();
  const productsRef = useMemoFirebase(() => collection(firestore, "products"), [firestore]);
  const { data: products, isLoading } = useCollection(productsRef);
  const { t } = useLanguage();

  const [orderForm, setOrderForm] = useState({ name: "", email: "", phone: "" });
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    setIsSubmitting(true);
    
    try {
      const ordersRef = collection(firestore, "orders");
      await addDocumentNonBlocking(ordersRef, {
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        customerName: orderForm.name,
        customerEmail: orderForm.email,
        customerPhone: orderForm.phone,
        status: "pending",
        createdAt: new Date().toISOString(),
      });
      
      toast({
        title: t.shop.orderReceived,
        description: t.shop.orderDescription,
      });
      setIsDialogOpen(false);
      setOrderForm({ name: "", email: "", phone: "" });
    } catch (error) {
      toast({ variant: "destructive", title: "Order failed" });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <section id="shop" className="py-24 bg-background/50">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-muted-foreground animate-pulse font-black uppercase tracking-widest">{t.shop.opening}</p>
        </div>
      </section>
    );
  }

  if (!products || products.length === 0) return null;

  return (
    <section id="shop" className="py-24 bg-art-gradient overflow-hidden border-y border-border/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <div className="inline-block px-6 py-1 rounded-full border border-primary text-primary font-black tracking-widest uppercase text-[10px] mb-4">
            {t.shop.badge}
          </div>
          <h2 className="font-headline text-4xl md:text-5xl font-bold">Collab <span className="text-gold-gradient">Merchandise</span></h2>
          <p className="text-muted-foreground max-w-2xl mx-auto font-medium">
            {t.shop.subtitle}
          </p>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full relative"
        >
          <CarouselContent className="-ml-4 md:-ml-8">
            {products.map((product) => (
              <CarouselItem key={product.id} className="pl-4 md:pl-8 md:basis-1/2 lg:basis-1/3">
                <div className="group bg-card rounded-[2.5rem] overflow-hidden border border-border shadow-xl transition-all duration-500 h-full flex flex-col">
                  <div className="relative aspect-square overflow-hidden bg-muted/20">
                    <Image
                      src={product.imageUrl}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                      unoptimized
                    />
                    <div className="absolute top-6 right-6">
                      <div className="bg-foreground text-background font-black text-lg px-6 py-2 rounded-2xl shadow-2xl">
                        {product.price} DZD
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-8 space-y-4 flex-1 flex flex-col">
                    <h3 className="font-headline text-2xl font-black">{product.name}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed flex-1 font-medium">
                      {product.description}
                    </p>
                    
                    <Dialog open={isDialogOpen && selectedProduct?.id === product.id} onOpenChange={(open) => {
                      setIsDialogOpen(open);
                      if (open) setSelectedProduct(product);
                    }}>
                      <DialogTrigger asChild>
                        <Button className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/30 flex items-center gap-3 transition-transform hover:scale-[1.02]">
                          <ShoppingCart className="w-5 h-5" /> {t.shop.buyNow}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="rounded-[3rem] border-none shadow-2xl bg-card sm:max-w-[425px]">
                        <DialogHeader className="space-y-4">
                          <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
                            <Package className="text-primary w-8 h-8" />
                          </div>
                          <DialogTitle className="text-3xl font-black text-center">{t.shop.confirmOrder}</DialogTitle>
                          <DialogDescription className="text-center font-bold">
                            {t.shop.ordering}: <span className="text-primary">{product.name}</span>
                          </DialogDescription>
                        </DialogHeader>
                        
                        <form onSubmit={handleOrder} className="space-y-6 pt-6">
                          <div className="space-y-2">
                            <Label className="font-black text-[10px] uppercase tracking-widest ml-1 opacity-60">{t.shop.fullName}</Label>
                            <Input 
                              required 
                              value={orderForm.name} 
                              onChange={e => setOrderForm({...orderForm, name: e.target.value})} 
                              className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-primary" 
                              placeholder="..."
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="font-black text-[10px] uppercase tracking-widest ml-1 opacity-60">{t.shop.phone}</Label>
                            <Input 
                              required 
                              value={orderForm.phone} 
                              onChange={e => setOrderForm({...orderForm, phone: e.target.value})} 
                              className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-primary" 
                              placeholder="05XX XX XX XX"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="font-black text-[10px] uppercase tracking-widest ml-1 opacity-60">{t.shop.email}</Label>
                            <Input 
                              type="email" 
                              value={orderForm.email} 
                              onChange={e => setOrderForm({...orderForm, email: e.target.value})} 
                              className="h-14 rounded-2xl bg-muted/20 border-transparent focus:border-primary" 
                              placeholder="..."
                            />
                          </div>
                          
                          <Button type="submit" className="w-full h-16 bg-primary rounded-2xl font-black text-lg shadow-xl shadow-primary/20" disabled={isSubmitting}>
                            {isSubmitting ? <RefreshCcw className="w-6 h-6 animate-spin" /> : t.shop.confirm}
                          </Button>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          <div className="flex justify-center items-center gap-4 mt-16">
            <CarouselPrevious className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
            <CarouselNext className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}