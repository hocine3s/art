"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Send, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useFirestore, addDocumentNonBlocking } from "@/firebase";
import { collection } from "firebase/firestore";
import { useLanguage } from "@/components/language-provider";

const formSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Invalid phone number"),
  department: z.string().min(2, "Please specify your major"),
  portfolioLink: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

export function JoinUs() {
  const { toast } = useToast();
  const firestore = useFirestore();
  const { t } = useLanguage();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      department: "",
      portfolioLink: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSubmitting(true);
    try {
      const membersRef = collection(firestore, "members");
      addDocumentNonBlocking(membersRef, {
        fullName: values.fullName,
        email: values.email,
        phoneNumber: values.phone,
        universityDepartment: values.department,
        portfolioLink: values.portfolioLink || null,
        registeredAt: new Date().toISOString(),
      });
      toast({
        title: t.join.success,
        description: t.join.successDesc,
      });
      form.reset();
    } catch (error) {
      toast({
        variant: "destructive",
        title: t.join.error,
        description: t.join.errorDesc,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="join-us" className="py-24 relative overflow-hidden bg-background">
      <div className="absolute -top-10 -right-10 w-64 h-64 bg-primary/5 rounded-full blur-2xl" />
      <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-secondary/5 rounded-full blur-2xl" />

      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-card rounded-[2rem] shadow-2xl overflow-hidden flex flex-col md:flex-row border border-border">
          <div className="bg-primary p-12 text-primary-foreground md:w-1/3 flex flex-col justify-center">
            <UserPlus className="w-16 h-16 mb-6" />
            <h2 className="font-headline text-3xl font-bold mb-4">{t.join.title}</h2>
            <p className="text-primary-foreground/80 font-medium">
              {t.join.subtitle}
            </p>
          </div>

          <div className="p-8 md:p-12 flex-1">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-xs uppercase tracking-widest font-bold">{t.join.fullName}</Label>
                  <Input 
                    id="fullName" 
                    placeholder="..." 
                    {...form.register("fullName")}
                    className="rounded-xl border-border bg-muted/10 focus:ring-primary h-12"
                  />
                  {form.formState.errors.fullName && (
                    <p className="text-xs text-destructive">{form.formState.errors.fullName.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-xs uppercase tracking-widest font-bold">{t.join.universityEmail}</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="..." 
                    {...form.register("email")}
                    className="rounded-xl border-border bg-muted/10 focus:ring-primary h-12"
                  />
                  {form.formState.errors.email && (
                    <p className="text-xs text-destructive">{form.formState.errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-xs uppercase tracking-widest font-bold">{t.join.phone}</Label>
                  <Input 
                    id="phone" 
                    placeholder="..." 
                    {...form.register("phone")}
                    className="rounded-xl border-border bg-muted/10 focus:ring-primary h-12"
                  />
                  {form.formState.errors.phone && (
                    <p className="text-xs text-destructive">{form.formState.errors.phone.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department" className="text-xs uppercase tracking-widest font-bold">{t.join.department}</Label>
                  <Input 
                    id="department" 
                    placeholder="..." 
                    {...form.register("department")}
                    className="rounded-xl border-border bg-muted/10 focus:ring-primary h-12"
                  />
                  {form.formState.errors.department && (
                    <p className="text-xs text-destructive">{form.formState.errors.department.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="portfolioLink" className="text-xs uppercase tracking-widest font-bold">{t.join.portfolio}</Label>
                <Input 
                  id="portfolioLink" 
                  placeholder="..." 
                  {...form.register("portfolioLink")}
                  className="rounded-xl border-border bg-muted/10 focus:ring-primary h-12"
                />
                {form.formState.errors.portfolioLink && (
                  <p className="text-xs text-destructive">{form.formState.errors.portfolioLink.message}</p>
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl h-14 text-lg font-bold transition-all transform hover:scale-[1.01] shadow-xl shadow-primary/20"
                disabled={isSubmitting}
              >
                {isSubmitting ? t.join.submitting : (
                  <span className="flex items-center gap-2">
                    {t.join.submit} <Send className="w-5 h-5" />
                  </span>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}