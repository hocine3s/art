"use client";

import Image from "next/image";
import { Calendar as CalendarIcon, MapPin, Clock } from "lucide-react";
import { format } from "date-fns";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy } from "firebase/firestore";
import { useLanguage } from "@/components/language-provider";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export function Events() {
  const firestore = useFirestore();
  const eventsRef = useMemoFirebase(() => query(collection(firestore, "events"), orderBy("date", "asc")), [firestore]);
  const { data: events, isLoading } = useCollection(eventsRef);
  const { t } = useLanguage();

  if (isLoading) {
    return (
      <section id="events" className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-muted-foreground animate-pulse">{t.events.loading}</p>
        </div>
      </section>
    );
  }

  if (!events || events.length === 0) {
    return null;
  }

  return (
    <section id="events" className="py-24 bg-card/10 border-y border-border/50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="space-y-4">
            <h2 className="font-headline text-4xl md:text-5xl font-bold">{t.events.title}</h2>
            <p className="text-muted-foreground max-w-xl">
              {t.events.subtitle}
            </p>
          </div>
          <div className="w-32 h-32 hidden md:block border-8 border-primary/20 rounded-full animate-pulse" />
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full relative"
        >
          <CarouselContent className="-ml-4 md:-ml-8">
            {events.map((event) => (
              <CarouselItem key={event.id} className="pl-4 md:pl-8 md:basis-1/2 lg:basis-1/2">
                <div className="group bg-card rounded-[2.5rem] overflow-hidden border border-border shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col lg:flex-row h-full">
                  <div className="relative w-full lg:w-2/5 aspect-video lg:aspect-auto min-h-[250px]">
                    <Image
                      src={event.coverImageUrl || `https://picsum.photos/seed/${event.id}/800/500`}
                      alt={event.title}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-105"
                      unoptimized={true}
                    />
                  </div>
                  
                  <div className="p-8 flex-1 flex flex-col justify-between">
                    <div className="space-y-4">
                      <h3 className="font-headline text-2xl font-black group-hover:text-primary transition-colors">
                        {event.title}
                      </h3>
                      
                      <div className="grid grid-cols-1 gap-y-3">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-bold">
                          <CalendarIcon className="w-4 h-4 text-secondary" />
                          {event.date ? format(new Date(event.date), 'MMMM dd, yyyy') : t.events.dateTbd}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-bold">
                          <Clock className="w-4 h-4 text-secondary" />
                          {event.time || t.events.timeTbd}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground font-bold">
                          <MapPin className="w-4 h-4 text-secondary" />
                          {event.location}
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                        {event.description}
                      </p>
                    </div>
                    
                    <button className="mt-8 text-primary font-black uppercase tracking-widest text-xs hover:underline self-start">
                      {t.events.saveDate} &rarr;
                    </button>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          <div className="flex justify-center items-center gap-4 mt-16">
            <CarouselPrevious className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
            <CarouselNext className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}