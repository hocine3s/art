"use client";

import Image from "next/image";
import { ExternalLink, Palette } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy } from "firebase/firestore";
import { useLanguage } from "@/components/language-provider";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export function Gallery() {
  const firestore = useFirestore();
  const artworksRef = useMemoFirebase(() => query(collection(firestore, "artworks"), orderBy("createdAt", "desc")), [firestore]);
  const { data: artworks, isLoading } = useCollection(artworksRef);
  const { t } = useLanguage();

  if (isLoading) {
    return (
      <section id="gallery" className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-muted-foreground animate-pulse">{t.gallery.loading}</p>
        </div>
      </section>
    );
  }

  return (
    <section id="gallery" className="py-24 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-headline text-4xl md:text-5xl font-bold">{t.gallery.title}</h2>
          <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {t.gallery.subtitle}
          </p>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full relative"
        >
          <CarouselContent className="-ml-4 md:-ml-8">
            {artworks?.map((art) => (
              <CarouselItem key={art.id} className="pl-4 md:pl-8 md:basis-1/2 lg:basis-1/3">
                <div className="group bg-card rounded-[2.5rem] overflow-hidden border border-border shadow-xl hover:shadow-2xl transition-all duration-500 h-full flex flex-col">
                  <div className="relative aspect-[4/5] overflow-hidden">
                    <Image
                      src={art.imageUrl}
                      alt={art.title}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                      unoptimized={true}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-8">
                       <a 
                        href={art.artistProfileLink || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 text-white font-black uppercase tracking-widest text-xs hover:text-primary transition-colors"
                       >
                         {t.gallery.viewProfile} <ExternalLink className="w-4 h-4" />
                       </a>
                    </div>
                  </div>
                  
                  <div className="p-8 space-y-4 flex-1 flex flex-col">
                    <div className="flex justify-between items-start gap-3">
                      <h3 className="font-headline text-2xl font-black leading-tight tracking-tight">{art.title}</h3>
                      <Badge variant="secondary" className="bg-primary/10 text-primary border-none font-black uppercase tracking-tighter text-[10px] px-3">
                        {art.medium}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-2 text-[#D4AF37] font-black text-xs uppercase tracking-widest">
                      <Palette className="w-4 h-4" />
                      {art.artistFullName}
                    </div>
                    
                    <p className="text-sm text-muted-foreground line-clamp-4 leading-relaxed font-medium">
                      {art.description}
                    </p>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          
          <div className="flex justify-center items-center gap-4 mt-16">
            <CarouselPrevious className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
            <CarouselNext className="static translate-y-0 w-14 h-14 rounded-2xl border-2 hover:bg-primary hover:text-white transition-all shadow-lg" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}