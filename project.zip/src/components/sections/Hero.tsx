"use client";

import { Button } from "@/components/ui/button";
import { Trophy } from "lucide-react";
import Image from "next/image";
import { useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/components/language-provider";

const AnimatedHeader = ({ text, className, colorClass }: { text: string; className?: string; colorClass?: string }) => {
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  // For Arabic, we don't split by characters to preserve the cursive joining (ligation)
  if (isArabic) {
    return (
      <span className={cn("inline-flex flex-wrap animate-in fade-in slide-in-from-bottom-4 duration-1000 font-calligraphy", className, colorClass)}>
        {text}
      </span>
    );
  }

  return (
    <span className={cn("inline-flex flex-wrap", className)}>
      {text.split("").map((char, i) => (
        <span
          key={i}
          className={cn(
            "animate-in fade-in slide-in-from-bottom-4 transition-all duration-700 animate-text-color-cycle cursor-default",
            char === " " ? "mr-4" : "",
            colorClass
          )}
          style={{ 
            transitionDelay: `${i * 30}ms`,
            animationDelay: `${i * 80}ms`,
            display: "inline-block"
          }}
        >
          {char}
        </span>
      ))}
    </span>
  );
};

export function Hero() {
  const firestore = useFirestore();
  const settingsRef = useMemoFirebase(() => doc(firestore, "clubSettings", "global"), [firestore]);
  const { data: settings } = useDoc(settingsRef);
  const { t, language, dir } = useLanguage();

  const isArabic = language === 'ar';

  // Support Arabic-specific content overrides
  const customTitle = isArabic ? settings?.heroTitleAr : settings?.heroTitle;
  const customDescription = isArabic ? settings?.heroDescriptionAr : settings?.heroDescription;

  const titleText = customTitle || "L'Artelier Oran";
  const descriptionText = customDescription || t.hero.description;
  const heroImage = settings?.heroImageUrl || "https://picsum.photos/seed/art-hero/1000/1000";

  return (
    <section className="relative min-h-screen flex items-center pt-28 overflow-hidden bg-art-gradient">
      <div className="absolute top-0 right-0 -z-10 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[150px] animate-pulse" />
      <div className="absolute bottom-0 left-0 -z-10 w-[600px] h-[600px] bg-[#D4AF37]/10 rounded-full blur-[120px]" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center">
        <div className={cn(
          "space-y-12 animate-in fade-in duration-1000", 
          dir === 'rtl' ? 'slide-in-from-right text-right items-end' : 'slide-in-from-left text-left items-start'
        )}>
          <div className={cn("flex flex-col gap-4", dir === 'rtl' ? 'items-end' : 'items-start')}>
            <div className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-foreground/5 text-foreground text-xs font-black uppercase tracking-[0.2em] border border-foreground/10 animate-in fade-in slide-in-from-top duration-700">
              <Trophy className="w-4 h-4 text-[#D4AF37]" />
              {t.hero.badge}
            </div>
            
            <h1 className={cn(
              "font-headline font-black leading-[0.9] tracking-tighter group select-none",
              isArabic ? "text-7xl md:text-8xl lg:text-[9rem] font-calligraphy" : "text-6xl md:text-7xl lg:text-[8rem]"
            )}>
              <div className="mb-2">
                <AnimatedHeader text={titleText} colorClass="text-black dark:text-white" />
              </div>
              <span className={cn(
                "block font-black uppercase tracking-[0.4em] text-gold-gradient mt-4 animate-in fade-in zoom-in duration-1000 delay-500",
                isArabic ? "text-[0.3em] tracking-normal" : "text-[0.4em]"
              )}>
                x LMHTY
              </span>
            </h1>
          </div>
          
          <p className={cn(
            "text-2xl text-muted-foreground max-w-lg leading-relaxed font-medium animate-in fade-in duration-1000 delay-700", 
            dir === 'rtl' ? 'border-r-4 pr-8 text-right font-arabic' : 'border-l-4 pl-8 text-left', 
            "border-[#D4AF37]"
          )}>
            {descriptionText}
          </p>
          
          <div className={cn("flex flex-wrap gap-8 pt-4 animate-in fade-in slide-in-from-bottom duration-1000 delay-1000", dir === 'rtl' ? 'justify-end' : 'justify-start')}>
            <Button size="lg" className="bg-primary hover:bg-primary/90 rounded-2xl px-12 h-16 text-xl font-black shadow-2xl shadow-primary/30 transition-all hover:scale-105" asChild>
              <a href="#gallery">{t.hero.explore}</a>
            </Button>
            <Button size="lg" variant="outline" className="border-2 border-foreground hover:bg-foreground hover:text-background rounded-2xl px-12 h-16 text-xl font-black transition-all hover:scale-105" asChild>
              <a href="#join-us">{t.hero.join}</a>
            </Button>
          </div>
        </div>

        <div className="relative aspect-square lg:h-[750px] animate-in fade-in zoom-in duration-1000">
          <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 via-transparent to-[#D4AF37]/20 rounded-[4rem] transform rotate-3" />
          <div className="relative h-full w-full rounded-[4rem] overflow-hidden border-[12px] border-card shadow-2xl">
            <Image
              src={heroImage}
              alt="Artistic collaboration"
              fill
              priority
              className="object-cover transition-transform duration-700 hover:scale-110"
              unoptimized={true}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          </div>
        </div>
      </div>
    </section>
  );
}
