
"use client";

import { cn } from "@/lib/utils";
import Image from "next/image";
import { useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { useState, useEffect } from "react";

interface LogoProps {
  className?: string;
  forceSvg?: boolean;
}

export function LArtelierLogo({ className, forceSvg = false }: LogoProps) {
  const firestore = useFirestore();
  const settingsRef = useMemoFirebase(() => doc(firestore, "clubSettings", "global"), [firestore]);
  const { data: settings } = useDoc(settingsRef);
  const [imageError, setImageError] = useState(false);

  // Reset error state if the URL changes
  useEffect(() => {
    setImageError(false);
  }, [settings?.logoUrl]);

  const logoSrc = settings?.logoUrl || null;

  if (!forceSvg && logoSrc && !imageError) {
    return (
      <div className={cn("relative w-full h-full overflow-hidden rounded-full flex items-center justify-center bg-transparent", className)}>
        <Image 
          src={logoSrc} 
          alt="L'Artelier Logo" 
          fill 
          className="object-contain"
          onError={() => setImageError(true)}
          unoptimized={true}
        />
      </div>
    );
  }

  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("w-full h-full drop-shadow-xl", className)}
    >
      <mask id="circle-mask">
        <circle cx="50" cy="50" r="48" fill="white" />
      </mask>
      
      <g mask="url(#circle-mask)">
        <path d="M0 0H100V55L50 45L0 55V0Z" fill="#87CEEB" />
        <path d="M0 55L50 45V100H0V55Z" fill="#E34234" />
        <path d="M50 45L100 55V100H50V45Z" fill="#F4C430" />
      </g>
      <path
        d="M32 72C32 72 35 45 50 25C65 45 68 72 68 72H58C58 72 55 55 50 45C45 55 42 72 42 72H32Z"
        fill="white"
      />
      <path
        d="M38 58H62V64H38V58Z"
        fill="white"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M50 22C46 22 30 60 26 78H38C40 68 44 54 50 54C56 54 60 68 62 78H74C70 60 54 22 50 22ZM50 36L44 50H56L50 36Z"
        fill="white"
      />
      <circle cx="50" cy="50" r="48" stroke="white" strokeWidth="0.5" strokeOpacity="0.2" />
    </svg>
  );
}
