"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Menu, X, Moon, Sun, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTheme } from "next-themes";
import { LArtelierLogo } from "@/components/ui/logo";
import { useLanguage } from "@/components/language-provider";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const AnimatedText = ({ text, className, colorClass }: { text: string; className?: string; colorClass?: string }) => {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  
  // For Arabic, we don't split by characters to preserve the cursive joining (ligation)
  if (isArabic) {
    return (
      <span className={cn("inline-flex animate-in fade-in slide-in-from-bottom-2 duration-700 font-calligraphy", className, colorClass)}>
        {text}
      </span>
    );
  }

  return (
    <span className={cn("inline-flex overflow-hidden", className)}>
      {text.split("").map((char, i) => (
        <span
          key={i}
          className={cn(
            "animate-char-bounce animate-text-color-cycle transition-all duration-300",
            char === " " ? "mx-1" : "",
            colorClass
          )}
          style={{ 
            transitionDelay: `${i * 30}ms`, 
            animationDelay: `${i * 80}ms` 
          }}
        >
          {char}
        </span>
      ))}
    </span>
  );
};

export function Navbar() {
  const router = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t, dir } = useLanguage();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: t.nav.gallery, href: "#gallery" },
    { name: t.nav.shop, href: "#shop" },
    { name: t.nav.events, href: "#events" },
    { name: t.nav.joinUs, href: "#join-us" },
  ];

  const handleLogoDoubleClick = () => {
    router.push("/admin");
  };

  if (!mounted) return null;

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4",
        isScrolled 
          ? "bg-background/90 backdrop-blur-xl shadow-lg border-b border-white/5" 
          : "bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className={cn("flex items-center gap-4 group cursor-pointer select-none", dir === 'rtl' ? 'flex-row-reverse' : '')}
          onDoubleClick={handleLogoDoubleClick}
          title={t.nav.adminAccess}
        >
          <div className="w-12 h-12 group-hover:scale-110 transition-transform duration-500">
            <LArtelierLogo />
          </div>
          <div className={cn("flex flex-col", dir === 'rtl' ? 'items-end' : 'items-start')}>
            <div className={cn("font-headline text-2xl font-black tracking-tight leading-none flex items-baseline", dir === 'rtl' ? 'flex-row-reverse' : '')}>
              <AnimatedText text="L'Artelier" colorClass="text-black dark:text-white" />
              <span className="mx-1"></span>
              <AnimatedText text="Oran" colorClass="text-black dark:text-white" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground/60 mt-1">
              {t.nav.collab} <span className="text-gold-gradient">LMHTY</span>
            </span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className={cn("hidden md:flex items-center gap-10", dir === 'rtl' ? 'flex-row-reverse' : '')}>
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className={cn(
                "text-sm font-black uppercase tracking-widest hover:text-primary transition-all relative group",
                language === 'ar' ? 'font-arabic text-base' : ''
              )}
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
            </Link>
          ))}
          
          <div className={cn("flex items-center gap-2", dir === 'rtl' ? 'flex-row-reverse' : '')}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full w-10 h-10 hover:bg-muted/20">
                  <Languages className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={dir === 'rtl' ? 'start' : 'end'} className="rounded-2xl">
                <DropdownMenuItem onClick={() => setLanguage('en')} className="font-bold">English</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('fr')} className="font-bold">Français</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('ar')} className="font-bold font-arabic">العربية</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="rounded-full w-10 h-10 hover:bg-muted/20"
            >
              {theme === "dark" ? <Sun className="w-5 h-5 text-accent" /> : <Moon className="w-5 h-5 text-primary" />}
            </Button>
          </div>
        </div>

        {/* Mobile Toggle */}
        <div className={cn("flex items-center gap-2 md:hidden", dir === 'rtl' ? 'flex-row-reverse' : '')}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Languages className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align={dir === 'rtl' ? 'start' : 'end'} className="rounded-2xl">
              <DropdownMenuItem onClick={() => setLanguage('en')} className="font-bold">English</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('fr')} className="font-bold">Français</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('ar')} className="font-bold font-arabic">العربية</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-full"
          >
            {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
          <button
            className="p-2 text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-background/95 backdrop-blur-2xl border-b border-border p-8 flex flex-col gap-6 animate-in slide-in-from-top duration-300 text-center">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className={cn(
                "text-2xl font-black py-2 hover:text-primary",
                language === 'ar' ? 'font-arabic' : ''
              )}
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.name}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
