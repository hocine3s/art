
"use client";

import { Instagram, Facebook, MessageSquare, Youtube, ExternalLink, Mail } from "lucide-react";
import { LArtelierLogo } from "@/components/ui/logo";
import { useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { doc } from "firebase/firestore";
import { useLanguage } from "@/components/language-provider";
import { cn } from "@/lib/utils";

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
);

export function Footer() {
  const firestore = useFirestore();
  const settingsRef = useMemoFirebase(() => doc(firestore, "clubSettings", "global"), [firestore]);
  const { data: settings } = useDoc(settingsRef);
  const { t, language, dir } = useLanguage();

  const isArabic = language === 'ar';
  const customTagline = isArabic ? settings?.taglineAr : settings?.tagline;
  const taglineText = customTagline || t.footer.tagline;

  const instagram = settings?.instagramLink || "https://www.instagram.com/artelieroran";
  const facebook = settings?.facebookLink || "#";
  const discord = settings?.discordLink || "#";
  const youtube = settings?.youtubeLink || "#";

  return (
    <footer className="bg-slate-950 text-slate-50 py-32 px-6 border-t border-white/5 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#D4AF37]/5 blur-[120px] rounded-full -mr-48 -mt-48" />
      
      <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-20 items-start relative z-10 text-center md:text-left">
        <div className="space-y-10">
          <div className={cn("flex items-center gap-6", dir === 'rtl' ? 'flex-row-reverse' : '')}>
            <div className="w-20 h-20 drop-shadow-2xl">
              <LArtelierLogo />
            </div>
            <div className={cn("flex flex-col", dir === 'rtl' ? 'items-end' : 'items-start')}>
              <h2 className="font-headline text-3xl font-black tracking-tight leading-none">L'Artelier <span className="text-gold-gradient">Oran</span></h2>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 mt-2">Collab LMHTY</p>
            </div>
          </div>
          <p className={cn("text-slate-400 leading-relaxed max-w-sm font-medium text-lg", dir === 'rtl' ? 'text-right font-arabic' : 'text-left')}>
            {taglineText}
          </p>
        </div>
        
        <div className="space-y-10">
          <h3 className="font-black uppercase tracking-widest text-sm text-slate-500">{t.footer.navTitle}</h3>
          <ul className="space-y-5">
            <li><a href="#gallery" className="text-slate-300 hover:text-[#D4AF37] transition-all font-bold text-lg flex items-center justify-center md:justify-start gap-2 group">{t.nav.gallery} <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" /></a></li>
            <li><a href="#events" className="text-slate-300 hover:text-[#D4AF37] transition-all font-bold text-lg flex items-center justify-center md:justify-start gap-2 group">{t.nav.events} <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" /></a></li>
            <li><a href="#join-us" className="text-slate-300 hover:text-[#D4AF37] transition-all font-bold text-lg flex items-center justify-center md:justify-start gap-2 group">{t.nav.joinUs} <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" /></a></li>
          </ul>
        </div>

        <div className="space-y-10">
          <h3 className="font-black uppercase tracking-widest text-sm text-slate-500">{t.footer.connTitle}</h3>
          <div className="flex flex-wrap justify-center md:justify-start gap-5">
            {instagram && instagram !== "#" && (
              <a 
                href={instagram} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-[#D4AF37] transition-all group border border-white/5 shadow-2xl"
                title="Instagram"
              >
                <Instagram className="w-7 h-7 group-hover:scale-110 group-hover:text-black transition-transform" />
              </a>
            )}
            {facebook && facebook !== "#" && (
              <a 
                href={facebook} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-primary transition-all group border border-white/5 shadow-2xl"
                title="Facebook"
              >
                <Facebook className="w-7 h-7 group-hover:scale-110 transition-transform" />
              </a>
            )}
            {discord && discord !== "#" && (
              <a 
                href={discord} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-all group border border-white/5 shadow-2xl"
                title="Discord"
              >
                <MessageSquare className="w-7 h-7 group-hover:scale-110 transition-transform" />
              </a>
            )}
            {youtube && youtube !== "#" && (
              <a 
                href={youtube} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center hover:bg-red-600 transition-all group border border-white/5 shadow-2xl"
                title="YouTube"
              >
                <Youtube className="w-7 h-7 group-hover:scale-110 transition-transform" />
              </a>
            )}
          </div>
          <div className="pt-8 border-t border-white/5 flex flex-col items-center md:items-start gap-4">
            <p className={cn("text-xs text-slate-500 font-black uppercase tracking-[0.2em] leading-loose", dir === 'rtl' ? 'text-right' : 'text-left')}>
              © L'Artelier Oran x LMHTY <br />
              <span className="opacity-50 text-[10px]">{t.footer.location}</span>
            </p>
            <div className="group flex items-center gap-4 mt-4">
              <div className="flex items-center gap-3">
                <a href="https://www.instagram.com/lmhty?igsh=MWhsczRnMjBkaXZoYw==" target="_blank" rel="noopener noreferrer">
                  <Instagram className="w-4 h-4 text-slate-500 hover:text-[#D4AF37] transition-colors" />
                </a>
                <a href="https://wa.me/213659415311" target="_blank" rel="noopener noreferrer">
                  <WhatsAppIcon className="w-4 h-4 text-slate-500 hover:text-[#25D366] transition-colors" />
                </a>
                <a href="mailto:lmhty.sp@gmail.com">
                  <Mail className="w-4 h-4 text-slate-500 hover:text-primary transition-colors" />
                </a>
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-600 group-hover:text-[#D4AF37] transition-colors duration-500">
                {t.footer.digitalExp} <span className="text-slate-400 group-hover:text-white transition-colors">LMHTY</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
