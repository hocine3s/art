
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Next.js Middleware for Route Protection.
 * Acts as a firewall for the /admin route by checking for a valid session cookie
 * before the page is even rendered or data is fetched.
 */
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Protect all routes under the /admin path
  if (pathname.startsWith('/admin')) {
    const session = request.cookies.get('oran_admin_session');

    // If no session exists, we let the page load but the page component
    // itself will enforce the login view. For strict Zero-Trust, you could
    // redirect to a separate login page here.
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};
