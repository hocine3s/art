export const firebaseConfig = {
  "projectId": "studio-3782890500-1949e",
  "appId": "1:486562463067:web:f65ebc0eeb34b0b1f36e7e",
  "apiKey": "AIzaSyCjiT6VYp5raFxSxeY3rWIfmpFk5gKraXI",
  "authDomain": "studio-3782890500-1949e.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "486562463067"
};
