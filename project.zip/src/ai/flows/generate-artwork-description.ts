'use server';
/**
 * @fileOverview An AI agent that generates creative descriptions for artworks.
 *
 * - generateArtworkDescription - A function that handles the artwork description generation process.
 * - GenerateArtworkDescriptionInput - The input type for the generateArtworkDescription function.
 * - GenerateArtworkDescriptionOutput - The return type for the generateArtworkDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateArtworkDescriptionInputSchema = z.object({
  title: z.string().describe("The title of the artwork."),
  artistName: z.string().describe("The full name of the artist."),
  medium: z.string().describe("The medium used for the artwork (e.g., 'oil on canvas', 'sculpture', 'digital art')."),
});
export type GenerateArtworkDescriptionInput = z.infer<typeof GenerateArtworkDescriptionInputSchema>;

const GenerateArtworkDescriptionOutputSchema = z.string().describe("A creative and engaging description for the artwork.");
export type GenerateArtworkDescriptionOutput = z.infer<typeof GenerateArtworkDescriptionOutputSchema>;

export async function generateArtworkDescription(input: GenerateArtworkDescriptionInput): Promise<GenerateArtworkDescriptionOutput> {
  return generateArtworkDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateArtworkDescriptionPrompt',
  input: {schema: GenerateArtworkDescriptionInputSchema},
  output: {schema: GenerateArtworkDescriptionOutputSchema},
  prompt: `You are an art curator with a flair for descriptive and engaging language.
Your task is to write a creative and captivating description for an artwork based on the provided details.
The description should be engaging for an audience, highlighting the artwork's essence and the artist's intention.
Focus on imagery, emotion, and artistic style.

Artwork Title: {{{title}}}
Artist: {{{artistName}}}
Medium: {{{medium}}}

Generate a creative description for this artwork:`,
});

const generateArtworkDescriptionFlow = ai.defineFlow(
  {
    name: 'generateArtworkDescriptionFlow',
    inputSchema: GenerateArtworkDescriptionInputSchema,
    outputSchema: GenerateArtworkDescriptionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
