import { config } from 'dotenv';
config();

import '@/ai/flows/generate-artwork-description.ts';